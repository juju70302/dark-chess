#include "AI.h"

int AI::countTime(){
	return(int)(remainMilliSecond/MAX_STEP);
}

int AI::chooseFlip(){
	Color enemy=(state.myTurn)?BoardState::flipColor(state.myColor):state.myColor;

	for(int i=0;i<CHESS_NUM;i++){
		int safe=1;
		if(state.board[i]!=chessNum::dark||state.isAttackedByCannon(i,enemy))continue;
		for(int dir=chessDirection::min;dir<=chessDirection::max;dir++){
			int pos=BoardState::goNextPos[(dir<<5)|i];
			if((pos != chessPos::illegal)&&(state.board[pos] != chessNum::dark)&&
				(state.board[pos] != chessNum::empty)&&(BoardState::colorWithoutCheck(state.board[pos])==enemy)){
				if(BoardState::type(state.board[pos])<=chessNum::elephant){
					safe=0;
				}
			}
		}
		if(safe)return i;
	}

	for(int i=0;i<CHESS_NUM;i++)
		if(state.board[i]!=chessNum::dark)return i;
	return chessPos::illegal;
}

void AI::noFlipSearchMove(struct Move& moveOut,int milliseconds){
	std::chrono::high_resolution_clock::time_point start,stop;
	start = std::chrono::high_resolution_clock::now();

	//Iterative Deepening...
	for(int depth=MIN_SEARCH_DEPTH;depth<MAX_SEARCH_DEPTH;depth++){
		noFlipNegaScout(depth,moveOut);
		stop = std::chrono::high_resolution_clock::now();
#ifdef _INFORMATION_
		std::cout<<"depth "<<depth<<"\tusing time >> ";
		std::cout<<(std::chrono::duration_cast<std::chrono::milliseconds>(stop-start).count())<<std::endl;
#endif
		if(std::chrono::duration_cast<std::chrono::milliseconds>(stop-start).count()>=milliseconds)
			break;
	}
}

void AI::completeSearchMove(struct Move& moveOut,int milliseconds){
	std::chrono::high_resolution_clock::time_point start,stop;
	start = std::chrono::high_resolution_clock::now();
	int usingTime;
	int branch;

	struct Move moveList[Move::maxBranch+1];int order[Move::maxBranch+1];
	Color turn=(state.myTurn)?state.myColor:state.flipColor(state.myColor);
	branch=generateMove(state,moveList,turn,order);
	branch*=(state.closedNum[0]+state.closedNum[1]);
//std::cout<<"branch="<<branch<<std::endl;

	//Iterative Deepening...
	for(int depth=MIN_SEARCH_DEPTH;;depth++){
		completeNegaScout(depth,moveOut);
		stop = std::chrono::high_resolution_clock::now();
#ifdef _INFORMATION_
		std::cout<<"depth "<<depth<<"\tusing time >> ";
		std::cout<<(std::chrono::duration_cast<std::chrono::milliseconds>(stop-start).count())<<std::endl;
#endif
		usingTime=std::chrono::duration_cast<std::chrono::milliseconds>(stop-start).count();
		if(usingTime>=milliseconds||(usingTime*(branch+1)>=milliseconds))
			break;
	}
}

int AI::noFlipNegaScout(int depth,struct Move& moveOut){
#ifdef _USING_TRANS_TABLE_
	#define nega_scout(depthPara) (negaScout(state,transTable,-1*infMaxScore,infMaxScore,depthPara))
	#define chance_node(index,depthPara) (chanceNodeSearch(state,transTable,moveList[order[index]].currentPos,-1*infMaxScore,infMaxScore,depthPara))
#else
	#define nega_scout(depthPara) (negaScout(state,-1*infMaxScore,infMaxScore,depthPara))
	#define chance_node(index,depthPara) (chanceNodeSearch(state,moveList[order[index]].currentPos,-1*infMaxScore,infMaxScore,depthPara))
#endif
	static const Score infMaxScore=(Score)10000000;
	struct Move moveList[Move::maxBranch+1];
	int order[Move::maxBranch+1];
	int moveNum,maxIndex;
	Score maxScore,thisScore;

	//generating move...
	moveNum=generateMoveWithoutFlip(state,moveList,(state.myTurn==0)?state.flipColor(state.myColor):state.myColor,order);

	if(moveNum==0)return 0;


//std::cout<<"movNum="<<moveNum<<std::endl;
//std::cout<<"0th move>>"<<moveList[order[0]].toString()<<std::endl;

	if(moveList[order[0]].type==moveType::flip){
		maxScore=chance_node(0,depth);
	}
	else{
		state.moveWithoutCheck(moveList[order[0]]);
		state.flipTurn();
		maxScore=-1*nega_scout(depth-1);
		state.flipTurn();
		state.unMove(moveList[order[0]]);
	}
	maxIndex=order[0];

//std::cout<<"flag2"<<std::endl;


	for(int moveIndex=1;moveIndex<2;moveIndex++){
		if(moveList[order[moveIndex]].type==moveType::flip){
			thisScore=chance_node(moveIndex,depth);
		}
		else{
			state.moveWithoutCheck(moveList[order[moveIndex]]);
			state.flipTurn();
			thisScore=-1*nega_scout(depth-1);
			state.flipTurn();
			state.unMove(moveList[order[moveIndex]]);
		}

//std::cout<<"node \""<<moveIndex<<"\"\n";

		if(thisScore>maxScore){
			maxIndex=order[moveIndex];
			maxScore=thisScore;
		}
	}
	moveOut=moveList[maxIndex];

	return 1;

#undef nega_scout
#undef chance_node
}

void AI::completeNegaScout(int depth,struct Move& moveOut){
#ifdef _USING_TRANS_TABLE_
	#define nega_scout(depthPara) (negaScout2(state,transTable,-1*infMaxScore,infMaxScore,depthPara))
	#define chance_node(index,depthPara) (chanceNodeSearch(state,transTable,moveList[order[index]].currentPos,-1*infMaxScore,infMaxScore,depthPara))
#else
	#define nega_scout(depthPara) (negaScout2(state,-1*infMaxScore,infMaxScore,depthPara))
	#define chance_node(index,depthPara) (chanceNodeSearch(state,moveList[order[index]].currentPos,-1*infMaxScore,infMaxScore,depthPara))
#endif
	static const Score infMaxScore=(Score)10000000;
	struct Move moveList[Move::maxBranch+1];
	int order[Move::maxBranch+1];
	int moveNum,maxIndex;
	Score maxScore,thisScore;

	//generating move...
	moveNum=generateMove(state,moveList,(state.myTurn==0)?state.flipColor(state.myColor):state.myColor,order);



//std::cout<<"movNum="<<moveNum<<std::endl;
//std::cout<<"0th move>>"<<moveList[order[0]].toString()<<std::endl;

	if(moveList[order[0]].type==moveType::flip){
		maxScore=chance_node(0,depth);
	}
	else{
		state.moveWithoutCheck(moveList[order[0]]);
		state.flipTurn();
		maxScore=-1*nega_scout(depth-1);
		state.flipTurn();
		state.unMove(moveList[order[0]]);
	}
	maxIndex=order[0];

//std::cout<<"flag2"<<std::endl;


	for(int moveIndex=1;moveIndex<2;moveIndex++){
		if(moveList[order[moveIndex]].type==moveType::flip){
			thisScore=chance_node(moveIndex,depth);
		}
		else{
			state.moveWithoutCheck(moveList[order[moveIndex]]);
			state.flipTurn();
			thisScore=-1*nega_scout(depth-1);
			state.flipTurn();
			state.unMove(moveList[order[moveIndex]]);
		}

//std::cout<<"node \""<<moveIndex<<"\"\n";

		if(thisScore>maxScore){
			maxIndex=order[moveIndex];
			maxScore=thisScore;
		}
	}
	moveOut=moveList[maxIndex];

#undef nega_scout
#undef chance_node
}

void AI::startGameMove(struct Move& moveOut){
	if(step==0){
		static const int firstFlipPos=0;
		moveOut.type=moveType::flip;
		moveOut.currentPos=firstFlipPos;
		moveOut.nextPos=firstFlipPos;
		return;
	}

	if(step==1){
		Chess firstFlipChess;
		int firstFlipPos,secondFlipPos;
		for(int i=0;i<CHESS_NUM;i++){
			if(state.board[i]!=chessNum::dark){
				firstFlipChess=state.board[i];
				firstFlipPos=i;
				break;
			}
		}
		if((BoardState::type(firstFlipChess) == chessNum::king)||
		  (BoardState::type(firstFlipChess) >= chessNum::knight)){
		  //flip aroud enemy's king and chess who is smaller than rook...
			for(int dir=chessDirection::min;dir<=chessDirection::max;dir++){
				if(BoardState::goNextPos[(dir<<5)|firstFlipPos]!=chessPos::illegal){
					moveOut.currentPos=BoardState::goNextPos[(dir<<5)|firstFlipPos];
					moveOut.nextPos=moveOut.currentPos;
					moveOut.type=moveType::flip;
					return;
				}
			}
		}
		else{
			//flip with one chess's gap...
			for(int dir=chessDirection::min;dir<=chessDirection::max;dir++){
				if((BoardState::goNextPos[(dir<<5)|firstFlipPos]!=chessPos::illegal)&&
					(BoardState::goNextPos[(dir<<5)|BoardState::goNextPos[(dir<<5)|firstFlipPos]]!=chessPos::illegal)){
						moveOut.currentPos=BoardState::goNextPos[(dir<<5)|BoardState::goNextPos[(dir<<5)|firstFlipPos]];
						moveOut.nextPos=moveOut.currentPos;
						moveOut.type=moveType::flip;
						return;
				}
			}
		}
	}
}

int AI::move(const struct Move& moveIn){
	struct Move moveTest;moveTest=moveIn;
	if(!state.canMove(moveTest))return 0;
	if((step <= 0)&&(state.myColor != chessColor::red)&&(state.myColor != chessColor::black)){
		//first step,set color...
		state.myColor=BoardState::colorWithoutCheck(moveIn.nextChess);
		if(!state.myTurn)state.myColor=BoardState::flipColor(state.myColor);
	}

	state.moveWithoutCheck(moveIn);
	state.flipTurn();
	step++;
	return 1;
}

AI::AI(int tableSizeBitIn,int totalSecond):transTable(tableSizeBitIn){
	remainMilliSecond=1000*totalSecond;
	step=0;
}