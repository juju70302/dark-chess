#include "definition.h"
#include "search.h"
#include "board_state.h"
#include <chrono>

#ifndef _AI_H_
#define _AI_H_
class AI{
private:
	static const int MIN_SEARCH_DEPTH=3;
	static const int MAX_SEARCH_DEPTH=100;
	static const int MAX_STEP=100;
public:
	BoardState state;
	TransTable transTable;
	int step;
	int remainMilliSecond;

public:
	void startGameMove(struct Move& moveOut);
	void completeSearchMove(struct Move& moveOut,int milliseconds);
	void noFlipSearchMove(struct Move& moveOut,int milliseconds);
	int chooseFlip();

	int move(const struct Move& moveIn);
	void completeNegaScout(int depth,struct Move& moveOut);
	int noFlipNegaScout(int depth,struct Move& moveOut);

	//void moveGenerator();
	int countTime();

	AI(int tableSizeBitIn=20,int totalSecond=90);
};
#endif